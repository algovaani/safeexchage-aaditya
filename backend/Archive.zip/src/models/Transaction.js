import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      enum: [
        'deposit',
        'withdrawal',
        'trade_margin_locked',
        'trade_profit',
        'trade_loss',
        'trade_margin_returned',
        'stake_locked',
        'stake_principal_returned',
        'stake_reward',
        'stake_early_withdrawal',
        'referral_reward',
        'spot_buy',
        'spot_sell',
        'admin_credit',
        'admin_debit',
        'futures_margin_locked',
        'futures_margin_returned',
        'futures_profit',
        'futures_loss',
        'futures_fee',
      ],
      required: true,
    },
    amount: { type: Number, required: true },
    balanceAfter: { type: Number, default: null },
    currency: { type: String, default: 'USDT' },
    status: { type: String, enum: ['pending', 'approved', 'rejected', 'completed'], default: 'pending' },
    method: { type: String, enum: ['manual', 'gateway', 'crypto', 'fiat'], default: 'manual' },
    depositId: { type: mongoose.Schema.Types.ObjectId, ref: 'Deposit', default: null },
    withdrawalId: { type: mongoose.Schema.Types.ObjectId, ref: 'Withdrawal', default: null },
    orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'UserOrder', default: null },
    tradeId: { type: mongoose.Schema.Types.ObjectId, ref: 'AdminTrade', default: null },
    spotOrderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', default: null },
    spotTradeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Trade', default: null },
    reference: { type: String, default: '' },
    adminNote: { type: String, default: '' },
  },
  { timestamps: true }
);

export const Transaction = mongoose.model('Transaction', transactionSchema);
