import 'dotenv/config';
import http from 'http';
import path from 'path';
import mongoose from 'mongoose';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { globalApiRateLimit } from './middleware/apiRateLimit.js';
import { Server } from 'socket.io';
import { connectDb } from './config/db.js';
import { errorHandler } from './middleware/errorHandler.js';
import { notFound } from './middleware/notFound.js';
import { success } from './utils/response.js';
import { requireDb } from './middleware/requireDb.js';
import authRoutes from './routes/authRoutes.js';
import kycRoutes from './routes/kycRoutes.js';
import walletRoutes from './routes/walletRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import marketRoutes from './routes/marketRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import { depositRouter, depositsRouter } from './routes/depositRoutes.js';
import { withdrawalRouter, withdrawalsRouter } from './routes/withdrawalRoutes.js';
import tradeRoutes from './routes/tradeRoutes.js';
import stakingRoutes from './routes/stakingRoutes.js';
import configRoutes from './routes/configRoutes.js';
import marketingRoutes from './routes/marketingRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';
import transactionRoutes from './routes/transactionRoutes.js';
import cashInPersonRoutes from './routes/cashInPersonRoutes.js';
import futuresRoutes from './routes/futuresRoutes.js';
import { handleMarketSubscribe, handleMarketUnsubscribe, handleMarketDisconnect } from './services/marketStreamService.js';
import { bootstrapMarketData } from './services/marketBootstrap.js';
import { attachUserSockets } from './services/socketService.js';
import { seedTradingPairsIfEmpty, refreshTradingPairCache, ensureCommodityPairs } from './services/tradingPairService.js';
import { getCorsAllowedOrigins, corsPreflightMiddleware, logCorsConfig } from './config/cors.js';
import { installGracefulShutdown, installProcessHandlers } from './config/processStability.js';
import { isDbConnected } from './config/db.js';
import { getProcessRole, shouldRunHttp, shouldRunBackgroundJobs } from './config/processRole.js';
import { startBackgroundJobs, stopBackgroundJobs } from './jobs/backgroundJobs.js';
import { shutdownRedis } from './config/redis.js';
import { stopMarketLeaderElection } from './services/marketLeader.js';
import { stopMarketRedisBridge } from './services/marketRedisBridge.js';
import { migrateAllWalletBuckets } from './services/walletBucketService.js';
import { reconcileAllSellAssetLocks } from './services/sellLockRepairService.js';
import { preloadLiquidityUser } from './services/orderEngine.js';
import { getPlatformSettings } from './services/platformSettingsService.js';
import {
  attachSpotOrderMonitorIo,
  startSpotOrderMonitor,
  stopSpotOrderMonitor,
} from './services/spotOrderMonitor.js';

installProcessHandlers();

const ROLE = getProcessRole();

if (!process.env.JWT_SECRET || String(process.env.JWT_SECRET).length < 16) {
  console.error('[fatal] JWT_SECRET is missing or too short (min 16 chars). Refusing to start.');
  process.exit(1);
}

if (!shouldRunHttp()) {
  console.error(`[api] PROCESS_ROLE=${ROLE} — this entry is HTTP-only. Use src/worker.js for worker/scanner.`);
  process.exit(1);
}

const app = express();
const server = http.createServer(app);

// Behind Nginx/Apache — use real client IP for rate limiting
if (process.env.TRUST_PROXY !== '0') {
  app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
}

const corsOrigin = getCorsAllowedOrigins();
logCorsConfig();

const io = new Server(server, {
  cors: {
    origin: corsOrigin,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    credentials: true,
  },
});

app.set('io', io);

// Per-user private rooms for realtime wallet/balance pushes.
attachUserSockets(io);

app.use(corsPreflightMiddleware);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(
  cors({
    origin: corsOrigin,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin'],
    optionsSuccessStatus: 204,
    preflightContinue: false,
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

app.get('/', (_req, res) => {
  res.json({
    service: 'safex-backend',
    role: ROLE,
    health: '/api/health',
    market: '/api/market/prices/live',
    hint: 'All API routes are under /api — e.g. /api/auth/login, /api/market/ticker',
  });
});

// Coin logos stored in storage/coins (writable) — served under /uploads/coins for URL compatibility
app.use('/uploads/coins', express.static(path.join(process.cwd(), 'storage', 'coins')));
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
app.use('/storage', express.static(path.join(process.cwd(), 'storage')));

app.use('/api/', globalApiRateLimit);

app.get('/api/health', (_req, res) => {
  const dbOk = isDbConnected();
  return success(
    res,
    {
      ok: dbOk,
      service: 'safex-backend',
      role: ROLE,
      backgroundJobs: shouldRunBackgroundJobs(),
      database: dbOk ? 'connected' : 'disconnected',
      pid: process.pid,
    },
    dbOk ? 'Service healthy' : 'Database disconnected',
    dbOk ? 200 : 503
  );
});

app.use('/api', requireDb);

app.use('/api/auth', authRoutes);
app.use('/api/kyc', kycRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/deposit', depositRouter);
app.use('/api/deposits', depositsRouter);
app.use('/api/withdrawal', withdrawalRouter);
app.use('/api/withdrawals', withdrawalsRouter);
app.use('/api/orders', orderRoutes);
app.use('/api/trades', tradeRoutes);
app.use('/api/staking', stakingRoutes);
app.use('/api/config', configRoutes);
app.use('/api/marketing', marketingRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/cash-in-person', cashInPersonRoutes);
app.use('/api/futures', futuresRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/admin', adminRoutes);

app.use(notFound);
app.use(errorHandler);

io.on('connection', (socket) => {
  socket.on('market:subscribe', (payload) => {
    handleMarketSubscribe(io, socket, payload || {}).catch((err) => {
      console.warn('[market:subscribe]', err.message);
    });
  });

  socket.on('market:unsubscribe', (payload) => {
    handleMarketUnsubscribe(socket, payload || {});
  });

  socket.on('disconnect', () => {
    handleMarketDisconnect(socket);
  });
});

const PORT = Number(process.env.PORT) || 5001;

/** Pair cache needed for market routes even when crons run in a separate worker. */
async function warmApiCaches() {
  try {
    await seedTradingPairsIfEmpty();
    await ensureCommodityPairs();
    await refreshTradingPairCache();
    console.info('[pairs] Trading pair cache loaded (api)');
    try {
      const { updated } = await migrateAllWalletBuckets();
      if (updated > 0) {
        console.info(`[wallet] Migrated bucket balances for ${updated} wallet(s) (api)`);
      }
    } catch (err) {
      console.warn('[wallet] Bucket migration skipped:', err.message);
    }
    try {
      const { fixed } = await reconcileAllSellAssetLocks();
      if (fixed > 0) {
        console.info(`[orders] Reconciled stuck sell locks for ${fixed} asset row(s) (api)`);
      }
    } catch (err) {
      console.warn('[orders] Sell lock reconcile skipped:', err.message);
    }
    try {
      await preloadLiquidityUser();
      await getPlatformSettings();
      console.info('[orders] Liquidity user + platform settings warmed (api)');
    } catch (err) {
      console.warn('[orders] Trade warm-up skipped:', err.message);
    }
  } catch (err) {
    console.warn('[pairs] Cache init failed:', err.message);
  }
}

async function main() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error('MONGODB_URI is missing. Copy backend/.env.example to backend/.env');
  }

  const connectAttempts = process.env.NODE_ENV === 'production' ? 8 : 3;
  try {
    await connectDb(uri, { attempts: connectAttempts });
    console.log(`MongoDB connected (role=${ROLE})`);
    await bootstrapMarketData({ io });
    if (shouldRunBackgroundJobs()) {
      await startBackgroundJobs({ io });
    } else {
      console.info('[api] Background jobs disabled here — run safex-worker / PROCESS_ROLE=worker');
      attachSpotOrderMonitorIo(io);
      startSpotOrderMonitor();
      await warmApiCaches();
    }
  } catch (err) {
    console.error('MongoDB connection failed:', err.message);
    if (process.env.NODE_ENV === 'production') {
      console.warn(
        '[mongodb] API will listen — DB routes return 503 until connection succeeds (auto-retry in background)'
      );
      if (shouldRunBackgroundJobs()) {
        await startBackgroundJobs({ io });
      } else {
        attachSpotOrderMonitorIo(io);
        startSpotOrderMonitor();
        await warmApiCaches();
      }
    } else {
      console.warn(
        'Dev mode: API will listen, but auth/wallet routes return 503 until MongoDB is reachable.'
      );
    }
  }

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} already in use — stop the other process or change PORT in .env`);
    } else {
      console.error('HTTP server error:', err.message);
    }
    process.exit(1);
  });

  // Survive flaky mobile / Apache proxy connections (prevents idle socket drops mid-auth).
  server.keepAliveTimeout = Number(process.env.HTTP_KEEPALIVE_TIMEOUT_MS) || 65_000;
  server.headersTimeout = Number(process.env.HTTP_HEADERS_TIMEOUT_MS) || 70_000;
  server.requestTimeout = Number(process.env.HTTP_REQUEST_TIMEOUT_MS) || 60_000;

  server.listen(PORT, process.env.HOST || '0.0.0.0', () => {
    console.log(`API + WebSocket listening on :${PORT} (role=${ROLE}, pid=${process.pid})`);
    if (!isDbConnected()) {
      console.warn(
        'MongoDB still unreachable. Run: npm run db:check — then fix cluster/credentials or use local MONGODB_URI.'
      );
    }
  });

  installGracefulShutdown(server, {
    onShutdown: async () => {
      await stopMarketRedisBridge();
      await stopMarketLeaderElection();
      await shutdownRedis();
      if (shouldRunBackgroundJobs()) {
        await stopBackgroundJobs();
      } else {
        stopSpotOrderMonitor();
      }
      await mongoose.disconnect().catch(() => {});
    },
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
