import { Order } from '../models/Order.js';
import { Trade } from '../models/Trade.js';
import { Wallet } from '../models/Wallet.js';
import { Transaction } from '../models/Transaction.js';
import { User } from '../models/User.js';
import {
  baseAssetFromSymbol,
  creditAsset,
  debitLockedAsset,
  reconcileSellAssetLocks,
} from './assetBalanceService.js';
import { roundMoney, storeMoney } from '../utils/money.js';
import { unitPriceToUsdt } from '../utils/inrTrading.js';
import { debitForTrade, creditTradeProfit } from './walletAdjustmentService.js';

const FEE_RATE = 0.001;

/** Serialize order fills per symbol so concurrent price ticks cannot double-execute. */
const symbolOrderChains = new Map();

function withSymbolOrderLock(symbol, fn) {
  const sym = symbol.toUpperCase();
  const prev = symbolOrderChains.get(sym) || Promise.resolve();
  const run = prev.catch(() => {}).then(fn);
  symbolOrderChains.set(sym, run);
  return run.finally(() => {
    if (symbolOrderChains.get(sym) === run) {
      symbolOrderChains.delete(sym);
    }
  });
}

let liquidityUserIdPromise = null;

async function ensureLiquidityUserId() {
  const liqEmail = process.env.SYSTEM_LIQUIDITY_EMAIL || 'liquidity@internal.safex';
  let user = await User.findOne({ email: liqEmail }).select('_id').lean();
  if (user?._id) return user._id;

  user = await User.findOne({ role: 'system' }).select('_id').lean();
  if (user?._id) return user._id;

  const bcrypt = (await import('bcryptjs')).default;
  const passwordHash = await bcrypt.hash(
    process.env.SYSTEM_LIQUIDITY_PASSWORD || 'LiquidityInternal123!',
    12
  );
  const created = await User.create({
    email: liqEmail,
    passwordHash,
    name: 'Liquidity',
    role: 'system',
  });
  await Wallet.create({ userId: created._id, currency: 'USDT', balance: 0, lockedBalance: 0 });
  return created._id;
}

async function getLiquidityUserId() {
  if (!liquidityUserIdPromise) {
    liquidityUserIdPromise = ensureLiquidityUserId().catch((err) => {
      liquidityUserIdPromise = null;
      throw err;
    });
  }
  return liquidityUserIdPromise;
}

/**
 * @param {string} symbol
 * @param {number} currentPrice - mark / pulse price used to fill
 * @param {{ fromPrice?: number|null, rangeOnly?: boolean, priceHigh?: number|null, priceLow?: number|null }} [opts]
 *   With fromPrice (admin pulse): classic wick cross — buy if path low ≤ limit, sell if path high ≥ limit.
 *   priceHigh/priceLow: candle range for limit matching on normal ticks.
 *   Market orders always try to fill at currentPrice.
 */
export async function processOrdersForPrice(symbol, currentPrice, opts = {}) {
  return withSymbolOrderLock(symbol, () => processOrdersForPriceUnlocked(symbol, currentPrice, opts));
}

/** Fast path: fill a single order just created (skips extra DB read). */
export async function fillOrderAtPrice(order, symbol, currentPrice, opts = {}) {
  const sym = String(symbol).toUpperCase();
  return withSymbolOrderLock(sym, () => fillOrderAtPriceUnlocked(order, sym, currentPrice, opts));
}

async function fillOrderAtPriceUnlocked(order, sym, currentPrice, opts = {}) {
  const ord = order?.toObject ? order.toObject() : order;
  if (!ord || String(ord.symbol).toUpperCase() !== sym) return [];
  if (!['open', 'partially_filled'].includes(ord.status)) return [];

  const fillPriceUsdt = await unitPriceToUsdt(sym, currentPrice);
  if (!(fillPriceUsdt > 0)) return [];

  const remaining = ord.quantity - (ord.filledQuantity || 0);
  if (remaining <= 0) return [];

  const liquidityId = await getLiquidityUserId();

  if (ord.orderType === 'market') {
    const t = await executeInternalFill(ord, fillPriceUsdt, remaining, sym, liquidityId);
    return t ? [t] : [];
  }

  const fromRaw = opts.fromPrice != null ? Number(opts.fromPrice) : null;
  const fromUsdt =
    fromRaw != null && Number.isFinite(fromRaw) && fromRaw > 0
      ? await unitPriceToUsdt(sym, fromRaw)
      : null;
  const wickMode = Boolean(opts.rangeOnly && fromUsdt != null);
  const pathLo = fromUsdt != null ? Math.min(fromUsdt, fillPriceUsdt) : fillPriceUsdt;
  const pathHi = fromUsdt != null ? Math.max(fromUsdt, fillPriceUsdt) : fillPriceUsdt;

  const shouldFill = await orderShouldFill(
    ord,
    sym,
    fillPriceUsdt,
    currentPrice,
    opts,
    wickMode,
    pathLo,
    pathHi
  );
  if (!shouldFill) return [];

  const t = await executeInternalFill(ord, fillPriceUsdt, remaining, sym, liquidityId);
  return t ? [t] : [];
}

/** Fast path: fill only the order just created (avoids scanning all open orders). */
export async function processSingleOrderForPrice(orderId, symbol, currentPrice, opts = {}) {
  return withSymbolOrderLock(symbol, () =>
    processSingleOrderForPriceUnlocked(orderId, symbol, currentPrice, opts)
  );
}

/** Pre-warm liquidity user at startup (avoids first-order delay). */
export function preloadLiquidityUser() {
  return getLiquidityUserId().catch(() => null);
}

/** Push wallet + order-table updates after spot fills (best-effort). */
export async function notifySpotOrderFills(io, symbol, trades, { reason = 'spot_fill' } = {}) {
  if (!io || !trades?.length) return;
  const { emitWalletUpdate } = await import('./socketService.js');
  const userIds = new Set();
  for (const t of trades) {
    if (t.buyerUserId) userIds.add(String(t.buyerUserId));
    if (t.sellerUserId) userIds.add(String(t.sellerUserId));
  }
  for (const uid of userIds) {
    await emitWalletUpdate(io, uid, { reason }).catch(() => {});
  }
  io.emit('market:orders:filled', {
    symbol: String(symbol).toUpperCase(),
    count: trades.length,
    at: Date.now(),
  });
}

async function orderShouldFill(order, sym, fillPriceUsdt, currentPrice, opts, wickMode, pathLo, pathHi) {
  if (order.orderType === 'market') return true;
  if (order.orderType !== 'limit' || order.price == null) return false;

  const limitUsdt = await unitPriceToUsdt(sym, order.price);
  if (!(limitUsdt > 0)) return false;

  if (wickMode) {
    if (order.side === 'buy') return pathLo <= limitUsdt + 1e-10;
    if (order.side === 'sell') return pathHi >= limitUsdt - 1e-10;
    return false;
  }

  const hiRaw = opts.priceHigh != null ? Number(opts.priceHigh) : currentPrice;
  const loRaw = opts.priceLow != null ? Number(opts.priceLow) : currentPrice;
  const hiUsdt = await unitPriceToUsdt(sym, Math.max(hiRaw, currentPrice));
  const loUsdt = await unitPriceToUsdt(sym, Math.min(loRaw, currentPrice));

  if (order.side === 'buy') {
    return fillPriceUsdt <= limitUsdt + 1e-10 || loUsdt <= limitUsdt + 1e-10;
  }
  if (order.side === 'sell') {
    return fillPriceUsdt >= limitUsdt - 1e-10 || hiUsdt >= limitUsdt - 1e-10;
  }
  return false;
}

async function processSingleOrderForPriceUnlocked(orderId, symbol, currentPrice, opts = {}) {
  const sym = symbol.toUpperCase();
  const order = await Order.findById(orderId).lean();
  if (!order || String(order.symbol).toUpperCase() !== sym) return [];
  if (!['open', 'partially_filled'].includes(order.status)) return [];

  const fillPriceUsdt = await unitPriceToUsdt(sym, currentPrice);
  if (!(fillPriceUsdt > 0)) return [];

  const fromRaw = opts.fromPrice != null ? Number(opts.fromPrice) : null;
  const fromUsdt =
    fromRaw != null && Number.isFinite(fromRaw) && fromRaw > 0
      ? await unitPriceToUsdt(sym, fromRaw)
      : null;
  const wickMode = Boolean(opts.rangeOnly && fromUsdt != null);
  const pathLo = fromUsdt != null ? Math.min(fromUsdt, fillPriceUsdt) : fillPriceUsdt;
  const pathHi = fromUsdt != null ? Math.max(fromUsdt, fillPriceUsdt) : fillPriceUsdt;

  const shouldFill = await orderShouldFill(
    order,
    sym,
    fillPriceUsdt,
    currentPrice,
    opts,
    wickMode,
    pathLo,
    pathHi
  );
  if (!shouldFill) return [];

  const remaining = order.quantity - (order.filledQuantity || 0);
  if (remaining <= 0) return [];

  const liquidityId = await getLiquidityUserId();
  const t = await executeInternalFill(order, fillPriceUsdt, remaining, sym, liquidityId);
  return t ? [t] : [];
}

async function processOrdersForPriceUnlocked(symbol, currentPrice, opts = {}) {
  const sym = symbol.toUpperCase();
  const fillPriceUsdt = await unitPriceToUsdt(sym, currentPrice);
  if (!(fillPriceUsdt > 0)) return [];

  const fromRaw = opts.fromPrice != null ? Number(opts.fromPrice) : null;
  const fromUsdt =
    fromRaw != null && Number.isFinite(fromRaw) && fromRaw > 0
      ? await unitPriceToUsdt(sym, fromRaw)
      : null;
  const wickMode = Boolean(opts.rangeOnly && fromUsdt != null);
  const pathLo = fromUsdt != null ? Math.min(fromUsdt, fillPriceUsdt) : fillPriceUsdt;
  const pathHi = fromUsdt != null ? Math.max(fromUsdt, fillPriceUsdt) : fillPriceUsdt;
  const liquidityId = await getLiquidityUserId();
  const openOrders = await Order.find({
    symbol: sym,
    status: { $in: ['open', 'partially_filled'] },
  }).sort({ createdAt: 1 });

  const trades = [];

  for (const order of openOrders) {
    if (!['open', 'partially_filled'].includes(order.status)) continue;

    const shouldFill = await orderShouldFill(
      order,
      sym,
      fillPriceUsdt,
      currentPrice,
      opts,
      wickMode,
      pathLo,
      pathHi
    );
    if (!shouldFill) continue;

    const remaining = order.quantity - (order.filledQuantity || 0);
    if (remaining <= 0) continue;

    const t = await executeInternalFill(order, fillPriceUsdt, remaining, sym, liquidityId);
    if (t) trades.push(t);
  }

  return trades;
}

async function logSpotTransaction(userId, side, { symbol, quantity, price, fee, orderId, tradeId }) {
  const wallet = await Wallet.findOne({ userId }).lean();
  const notional = price * quantity;
  const amount = side === 'buy' ? notional + fee : notional - fee;
  const payload = {
    type: side === 'buy' ? 'spot_buy' : 'spot_sell',
    amount: roundMoney(amount),
    balanceAfter: roundMoney(wallet?.balance || 0),
    currency: 'USDT',
    status: 'completed',
    method: 'gateway',
    reference: `${symbol} ${side} ${quantity} @ ${roundMoney(price)}`,
    spotTradeId: tradeId,
    adminNote: `${symbol} ${side.toUpperCase()} ${quantity} @ ${roundMoney(price)} USDT`,
  };

  const pending = await Transaction.findOne({ userId, spotOrderId: orderId, status: 'pending' });
  if (pending) {
    await Transaction.findByIdAndUpdate(pending._id, payload);
    return;
  }

  await Transaction.create({
    userId,
    ...payload,
    spotOrderId: orderId,
  });
}

async function markSpotOrderTransaction(userId, orderId, status, note = '') {
  await Transaction.findOneAndUpdate(
    { userId, spotOrderId: orderId, status: 'pending' },
    { status, adminNote: note || undefined }
  );
}

async function executeInternalFill(order, price, qty, symbol, liquidityId) {
  const orderId = order._id;
  const userId = order.userId;
  const baseAsset = baseAssetFromSymbol(symbol);

  const claimed = await Order.findOneAndUpdate(
    {
      _id: orderId,
      status: { $in: ['open', 'partially_filled'] },
      filledQuantity: order.filledQuantity || 0,
      $expr: { $gte: [{ $subtract: ['$quantity', '$filledQuantity'] }, qty - 1e-10] },
    },
    {
      $inc: { filledQuantity: qty },
      $set: {
        avgFillPrice: price,
        status: order.filledQuantity + qty >= order.quantity - 1e-10 ? 'filled' : 'partially_filled',
      },
    },
    { new: true }
  );

  if (!claimed) return null;

  let wallet = await Wallet.findOne({ userId });

  if (!wallet && order.side === 'buy') {
    await Order.findByIdAndUpdate(orderId, {
      status: 'rejected',
      filledQuantity: order.filledQuantity || 0,
      avgFillPrice: order.avgFillPrice ?? null,
    });
    await markSpotOrderTransaction(userId, orderId, 'rejected', 'Insufficient USDT balance');
    return null;
  }

  if (!wallet && order.side === 'sell') {
    wallet = await Wallet.create({ userId, balance: 0, lockedBalance: 0 });
  }

  const notional = price * qty;
  const fee = storeMoney(notional * FEE_RATE);

  try {
    if (order.side === 'buy') {
      const cost = storeMoney(notional + fee);
      try {
        debitForTrade(wallet, cost);
      } catch {
        await Order.findByIdAndUpdate(orderId, {
          status: 'rejected',
          filledQuantity: order.filledQuantity || 0,
          avgFillPrice: order.avgFillPrice ?? null,
        });
        await markSpotOrderTransaction(userId, orderId, 'rejected', 'Insufficient USDT balance');
        return null;
      }
      await wallet.save();
      await creditAsset(userId, baseAsset, qty);
    } else {
      await debitLockedAsset(userId, baseAsset, qty);
      creditTradeProfit(wallet, storeMoney(notional - fee));
      await wallet.save();
    }
  } catch (err) {
    if (order.side === 'sell') {
      await reconcileSellAssetLocks(userId, baseAsset).catch(() => {});
    }
    await Order.findByIdAndUpdate(orderId, {
      status: 'rejected',
      filledQuantity: order.filledQuantity || 0,
      avgFillPrice: order.avgFillPrice ?? null,
    });
    await markSpotOrderTransaction(userId, orderId, 'rejected', err.message || 'Order rejected');
    return null;
  }

  const buyOrderId = orderId;
  const sellOrderId = orderId;
  const counterpartyId = liquidityId || (await getLiquidityUserId());
  const buyerUserId = order.side === 'buy' ? userId : counterpartyId;
  const sellerUserId = order.side === 'sell' ? userId : counterpartyId;

  const trade = await Trade.create({
    symbol,
    price,
    quantity: qty,
    buyerUserId,
    sellerUserId,
    buyOrderId,
    sellOrderId,
    fee,
  });

  void logSpotTransaction(userId, order.side, {
    symbol,
    quantity: qty,
    price,
    fee,
    orderId,
    tradeId: trade._id,
  }).catch(() => {});

  return trade;
}
