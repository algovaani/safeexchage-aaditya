import { verifyToken } from '../utils/token.js';
import { fetchWalletSnapshotForUser } from './walletSnapshotService.js';

export const ADMINS_ROOM = 'admins';

function userRoom(userId) {
  return `user:${String(userId)}`;
}

function joinUserRoom(socket, token) {
  try {
    if (!token) return false;
    const payload = verifyToken(token);
    const userId = String(payload.sub || payload.id || payload._id || '');
    if (!userId) return false;
    socket.userId = userId;
    socket.role = payload.role || 'user';
    socket.join(userRoom(userId));
    // Admins also join a shared room for deposit/withdrawal alerts.
    if (payload.role === 'admin') {
      socket.join(ADMINS_ROOM);
      socket.isAdmin = true;
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Attaches per-user private rooms so we can push realtime updates (wallet, etc.)
 * to a specific logged-in user. Anonymous sockets (market data) keep working.
 */
export function attachUserSockets(io) {
  io.use((socket, next) => {
    const token = socket.handshake?.auth?.token || socket.handshake?.query?.token;
    joinUserRoom(socket, token);
    next();
  });

  io.on('connection', (socket) => {
    // Allow late authentication (e.g. user logs in without reconnecting).
    socket.on('auth', (token) => {
      joinUserRoom(socket, token);
    });
  });
}

/** Push order row updates instantly (pending → filled). */
export function emitOrderUpdate(io, userId, order) {
  if (!io || !userId || !order) return;
  io.to(userRoom(userId)).emit('orders:update', {
    order,
    at: Date.now(),
  });
}

/** Push wallet without another DB round-trip. */
export function emitWalletPush(io, userId, wallet, reason = null) {
  if (!io || !userId || !wallet) return;
  io.to(userRoom(userId)).emit('wallet:update', {
    wallet,
    reason,
    at: Date.now(),
  });
}

/**
 * Pushes the user's latest wallet balance to all of their connected sockets.
 * Always reads a fresh snapshot from DB so clients never get stale data.
 */
export async function emitWalletUpdate(io, userId, { reason = null, wallet: existingWallet = null } = {}) {
  if (!io || !userId) return;
  try {
    const wallet = existingWallet || (await fetchWalletSnapshotForUser(userId));
    emitWalletPush(io, userId, wallet, reason);
  } catch {
    /* realtime is best-effort — never block the request flow */
  }
}

/** Push futures position updates to the user's private socket room. */
export function emitFuturesUpdate(io, userId, payload = {}) {
  if (!io || !userId) return;
  io.to(userRoom(userId)).emit('futures:update', {
    ...payload,
    at: Date.now(),
  });
}

/**
 * Push admin-only alerts (new deposit / withdrawal requests, count updates).
 * Best-effort — never throws.
 */
export function emitAdminNotification(io, payload = {}) {
  if (!io) return;
  try {
    io.to(ADMINS_ROOM).emit('admin:notification', {
      ...payload,
      at: payload.at || Date.now(),
    });
  } catch {
    /* realtime is best-effort */
  }
}
