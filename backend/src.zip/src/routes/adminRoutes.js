import { Router } from 'express';
import * as a from '../controllers/adminController.js';
import * as kycAdmin from '../controllers/kycAdminController.js';
import * as depositAdmin from '../controllers/depositAdminController.js';
import * as withdrawalAdmin from '../controllers/withdrawalAdminController.js';
import * as cashInPersonAdmin from '../controllers/cashInPersonAdminController.js';
import * as treasuryAdmin from '../controllers/treasuryAdminController.js';
import * as settingsAdmin from '../controllers/settingsAdminController.js';
import * as userWalletAdmin from '../controllers/userWalletAdminController.js';
import * as adminUser from '../controllers/adminUserController.js';
import * as marketingAdmin from '../controllers/marketingController.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { validateRequest } from '../middleware/validateRequest.js';
import { validateBody } from '../middleware/validate.js';
import { reviewKycValidators } from '../validators/kycValidators.js';
import {
  adminOrdersListValidators,
  adminKycListValidators,
  adminUsersListValidators,
} from '../validators/adminListValidators.js';
import {
  adminDepositListValidators,
  editDepositValidators,
  verifyDepositValidators,
} from '../validators/depositValidators.js';
import {
  adminWithdrawalListValidators,
  editWithdrawalValidators,
  verifyWithdrawalValidators,
} from '../validators/withdrawalValidators.js';
import {
  adminCashInPersonListValidators,
  verifyCashInPersonValidators,
} from '../validators/cashInPersonValidators.js';
import { manualPriceSchema } from '../validators/schemas.js';
import tradeRoutes from './admin/tradeRoutes.js';
import stakingAdminRoutes from './admin/stakingRoutes.js';
import tradingPairRoutes from './admin/tradingPairRoutes.js';
import futuresAdminRoutes from './admin/futuresRoutes.js';
import dashboardRoutes from './admin/dashboardRoutes.js';
import {
  treasuryListValidators,
  treasuryWithdrawValidators,
  treasurySweepValidators,
  treasuryDepositIdValidators,
} from '../validators/treasuryValidators.js';
import * as systemLogAdmin from '../controllers/systemLogAdminController.js';
import {
  adminSystemLogListValidators,
  clearSystemLogsValidators,
} from '../validators/systemLogValidators.js';
import { platformSettingsValidators } from '../validators/settingsValidators.js';
import {
  adjustUserFundsValidators,
  userFundHistoryValidators,
} from '../validators/userWalletValidators.js';
import { marketingBannerImageUploadSingle } from '../middleware/marketingBannerUpload.js';
import { marketingNoticeImageUploadSingle } from '../middleware/marketingNoticeUpload.js';
import {
  adminUserIdParamValidators,
  adminUserDepositsValidators,
  adminUserWithdrawalsValidators,
  adminUserTradesValidators,
  adminUserOrdersValidators,
  adminSetUserPasswordValidators,
  adminSetUserSupportAccessValidators,
  adminUserReferralsValidators,
} from '../validators/adminUserValidators.js';
import reportsRoutes from './admin/reportsRoutes.js';
import * as adminNotify from '../controllers/adminNotificationController.js';
import {
  bannerCreateValidators,
  bannerUpdateValidators,
  bannerDeleteValidators,
  noticeCreateValidators,
  noticeUpdateValidators,
  noticeDeleteValidators,
  supportCreateValidators,
  supportUpdateValidators,
} from '../validators/marketingValidators.js';

const r = Router();

r.use(requireAuth, requireAdmin);

r.get('/overview', a.overviewStats);
r.get('/notifications/summary', adminNotify.notificationSummary);
r.get('/notifications', adminNotify.listNotifications);
r.patch('/notifications/read-all', adminNotify.markAllRead);
r.patch('/notifications/:id/read', adminNotify.markRead);
r.post('/notifications/device', adminNotify.registerDevice);
r.post('/notifications/device/unregister', adminNotify.unregisterDevice);
r.get('/notifications/fcm-status', adminNotify.fcmStatus);
r.post('/notifications/test-push', adminNotify.testPush);
r.get('/users', adminUsersListValidators, validateRequest, a.listUsers);
r.post(
  '/users/:userId/fund-adjustment',
  adjustUserFundsValidators,
  validateRequest,
  userWalletAdmin.adjustUserFunds
);
r.get(
  '/users/:userId/fund-adjustments',
  userFundHistoryValidators,
  validateRequest,
  userWalletAdmin.listUserFundAdjustments
);
r.get('/users/:userId', adminUserIdParamValidators, validateRequest, adminUser.getUserDetail);
r.post(
  '/users/:userId/password',
  adminSetUserPasswordValidators,
  validateRequest,
  adminUser.setUserPassword
);
r.patch(
  '/users/:userId/support-access',
  adminSetUserSupportAccessValidators,
  validateRequest,
  adminUser.setUserSupportAccess
);
r.get('/users/:userId/deposits', adminUserDepositsValidators, validateRequest, adminUser.listUserDeposits);
r.get(
  '/users/:userId/withdrawals',
  adminUserWithdrawalsValidators,
  validateRequest,
  adminUser.listUserWithdrawals
);
r.get('/users/:userId/trades', adminUserTradesValidators, validateRequest, adminUser.listUserTrades);
r.get('/users/:userId/orders', adminUserOrdersValidators, validateRequest, adminUser.listUserOrders);
r.get(
  '/users/:userId/referrals',
  adminUserReferralsValidators,
  validateRequest,
  adminUser.listUserReferrals
);
r.get('/kyc', adminKycListValidators, validateRequest, kycAdmin.listSubmissions);
r.get('/kyc/:id', kycAdmin.getSubmission);
r.patch('/kyc/:id/review', reviewKycValidators, validateRequest, kycAdmin.reviewSubmission);
r.get('/deposits', adminDepositListValidators, validateRequest, depositAdmin.listDeposits);
r.get('/deposits/:id', depositAdmin.getDeposit);
r.patch(
  '/deposits/:id',
  editDepositValidators,
  validateRequest,
  depositAdmin.editDeposit
);
r.get('/deposits/:id/sweep-preview', treasuryDepositIdValidators, validateRequest, treasuryAdmin.getSweepPreview);
r.post('/deposits/:id/fund-gas', treasuryDepositIdValidators, validateRequest, treasuryAdmin.fundGas);
r.post(
  '/deposits/:id/sweep',
  treasuryDepositIdValidators,
  treasurySweepValidators,
  validateRequest,
  treasuryAdmin.autoSweepDeposit
);
r.patch('/deposits/:id/verify', verifyDepositValidators, validateRequest, depositAdmin.verifyDeposit);
r.post('/deposits/bulk/approve', depositAdmin.bulkDepositAction);
r.post('/deposits/bulk/reject', depositAdmin.bulkRejectDeposits);
r.post('/deposits/bulk/treasury-withdraw', treasuryWithdrawValidators, validateRequest, depositAdmin.bulkTreasuryWithdraw);
r.post(
  '/deposits/:id/treasury-withdraw',
  treasuryWithdrawValidators,
  validateRequest,
  treasuryAdmin.withdrawDepositToAdmin
);
r.get('/treasury/config', treasuryAdmin.treasuryConfig);
r.get('/treasury/pending-sweeps', treasuryAdmin.listPendingSweeps);
r.get('/treasury/sweep-preview/:id', treasuryDepositIdValidators, validateRequest, treasuryAdmin.getSweepPreview);
r.post('/treasury/fund-gas/:id', treasuryDepositIdValidators, validateRequest, treasuryAdmin.fundGas);
r.post(
  '/treasury/sweep/:id',
  treasuryDepositIdValidators,
  treasurySweepValidators,
  validateRequest,
  treasuryAdmin.autoSweepDeposit
);
r.get('/settings', settingsAdmin.getSettings);
r.put('/settings', platformSettingsValidators, validateRequest, settingsAdmin.updateSettings);
r.get(
  '/treasury-withdrawals',
  treasuryListValidators,
  validateRequest,
  treasuryAdmin.listTreasuryWithdrawals
);
r.get(
  '/withdrawals',
  adminWithdrawalListValidators,
  validateRequest,
  withdrawalAdmin.listWithdrawals
);
r.get(
  '/logs',
  adminSystemLogListValidators,
  validateRequest,
  systemLogAdmin.listSystemLogs
);
r.get('/logs/:id', systemLogAdmin.getSystemLog);
r.delete(
  '/logs',
  clearSystemLogsValidators,
  validateRequest,
  systemLogAdmin.clearSystemLogs
);
r.get('/withdrawals/:id', withdrawalAdmin.getWithdrawal);
r.patch(
  '/withdrawals/:id',
  editWithdrawalValidators,
  validateRequest,
  withdrawalAdmin.editWithdrawal
);
r.patch(
  '/withdrawals/:id/verify',
  verifyWithdrawalValidators,
  validateRequest,
  withdrawalAdmin.verifyWithdrawal
);
r.get(
  '/cash-in-person',
  adminCashInPersonListValidators,
  validateRequest,
  cashInPersonAdmin.listRequests
);
r.patch(
  '/cash-in-person/:id/verify',
  verifyCashInPersonValidators,
  validateRequest,
  cashInPersonAdmin.verifyRequest
);
r.get('/transactions', a.listPendingTransactions);
r.get('/transactions/all', a.listAllTransactions);
r.patch('/transactions/:id', a.approveTransaction);
r.get('/orders', adminOrdersListValidators, validateRequest, a.listAllOrders);
r.post('/manual-prices', validateBody(manualPriceSchema), a.upsertManualPrice);
r.get('/manual-prices', a.listManualPrices);
r.delete('/manual-prices/:id', a.deleteManualPrice);
r.get('/marketing/banners', marketingAdmin.listBanners);
r.post(
  '/marketing/banners',
  marketingBannerImageUploadSingle,
  bannerCreateValidators,
  validateRequest,
  marketingAdmin.createBanner
);
r.patch('/marketing/banners/:id', bannerUpdateValidators, validateRequest, marketingAdmin.updateBanner);
r.delete('/marketing/banners/:id', bannerDeleteValidators, validateRequest, marketingAdmin.deleteBanner);

r.get('/marketing/notices', marketingAdmin.listNotices);
r.post(
  '/marketing/notices',
  marketingNoticeImageUploadSingle,
  noticeCreateValidators,
  validateRequest,
  marketingAdmin.createNotice
);
r.patch('/marketing/notices/:id', noticeUpdateValidators, validateRequest, marketingAdmin.updateNotice);

r.delete('/marketing/notices/:id', noticeDeleteValidators, validateRequest, marketingAdmin.deleteNotice);

r.get('/marketing/support-contacts', marketingAdmin.listSupportContacts);
r.post(
  '/marketing/support-contacts',
  supportCreateValidators,
  validateRequest,
  marketingAdmin.createSupportContact
);
r.patch(
  '/marketing/support-contacts/:id',
  supportUpdateValidators,
  validateRequest,
  marketingAdmin.updateSupportContact
);
r.post('/prices/pulse', a.pulsePrice);
r.get('/prices/pulses', a.listPricePulses);
r.get('/ticker-stats', a.listTickerStats);
r.put('/ticker-stats/:symbol', a.upsertTickerStats);
r.delete('/ticker-stats/:symbol', a.clearTickerStats);
r.use('/dashboard', dashboardRoutes);
r.use('/reports', reportsRoutes);
r.use('/trades', tradeRoutes);
r.use('/staking', stakingAdminRoutes);
r.use('/trading-pairs', tradingPairRoutes);
r.use('/futures', futuresAdminRoutes);
r.get('/exchange-trades', a.allTrades);

export default r;
